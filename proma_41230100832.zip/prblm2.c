#include<stdio.h>
int main()
{
    int number, square;
    printf("Enter any integer value :");
    scanf("%d",&number);
    square = number * number;
    printf("Square of a given number %d is %d",number, square);
    return 0;
}
