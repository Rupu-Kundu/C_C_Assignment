#include<stdio.h>
int main()
{
    int a = 7, b = 5, add, sub, multi, div;
    add = a + b;
    sub = a - b;
    multi = a * b;
    div = a / b;
    printf("addition of %d + %d = %d\n",a,b,add);
    printf("subtraction of %d - %d = %d\n",a,b,sub);
    printf("multiplication of %d * %d = %d\n",a,b,multi);
    printf("division of %d / %d = %d",a,b,div);

    return 0;

}

