#include<stdio.h>
int main()
{
    printf("name : proma\n");
    printf("ID : 41230100832\n");
    printf("Department : CSE\n");
    printf("Email : rupu1794@gmail.com\n");
    printf("Address : 124, 1st Lane, Jame Mosjid Road, Dakshin Para, Dakshin Khan, Dhaka-1230.\n");
    printf("phone : 01776413876");


    return 0;
}
