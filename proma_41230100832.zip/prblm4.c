#include<stdio.h>
int main()
{
    float x,y,z, result;
    printf("Enter the 1st number : ");
    scanf("%f", &x);
    printf("Enter the 2nd number : ");
    scanf("%f", &y);
    printf("Enter the 3rd number : ");
    scanf("%f", &z);

    result = (1 + 1/(x*x) - 1/(y*y) + 1/(z*z) + 1/(x*y*z));
    printf("Result : %.9f", result);
    return 0;
}

